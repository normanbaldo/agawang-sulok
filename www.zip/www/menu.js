var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'gameDiv');

var basicGame=function(){}

basicGame.prototype={

    preload:function()
    {
    game.load.image("logo","img/menu.jpg")
    game.load.image("start","img/start.png")
    game.load.image("about","img/about.png")  
    },

    create:function(){
    game.physics.startSystem(Phaser.Physics.ARCADE);
    game.add.sprite(0,0,"logo");
    start = game.add.button(300, 300,"start", playGame);
    about = game.add.button(300, 450,"about", aboutGame);
    // game.load.audio("bgmusic")
    // bgmusic.play();
    },


    update: function ()
    {
    },
}

function playGame ()
    {
    window.location.href="main.html";
    {menus.frame=0}  
    setTimeout(function(){
    
    menus.frame=0;
    game._paused=false;
    },50);
    }
function aboutGame ()
    {
    window.location.href="about.html";
    {menus.frame=0}  
    setTimeout(function(){
    
    menus.frame=0;
    game._paused=false;
    },50);
    }

    game.state.add("mainGame",basicGame,true);
    game.state.start("mainState");