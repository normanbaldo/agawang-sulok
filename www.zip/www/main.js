var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'gameDiv');

var start, about, playGame, aboutGame;

var player;

var cursors;

var platform;

var bullet;
var bulletTime=0;
var fireButton;

var enemy;
var enemies;
var createEnemies;

var enemy2;
var enemies2;
var createEnemies2;

var coin;
var coins;
var createCoins;
var collectCoins, collectCoins2;

var coin2;
var coins2;
var createCoins2;

var score;
var bestScoreText;
var gameOverText;

var explode;

var button;
var button2;

var sun;
var clouds;

var gotomenu;
var pausebutton, playbutton, restartbutton;
var pause, play, restart;


var mainState = {

    preload:function(){

        game.load.image("bg","img/bg.jpg");
        game.load.image("tb","img/tb.png");
        game.load.spritesheet("player","img/avatar.png", 42.5, 120);
        game.load.image("plat","img/plat.png");
        game.load.image("bullet", "img/ar.png");
        game.load.image("enemy", "img/enemy.png");
        game.load.image("enemy2", "img/enemy2.png", 32, 28);
        game.load.image("coin", "img/tb.png");
        game.load.image("coin2", "img/tb2.png");
        game.load.spritesheet("explode", "img/ex.png", 118, 118);
        game.load.spritesheet("button","img/jump.png",250,200);
        game.load.spritesheet("button2","img/shoot.png",250,200);
        game.load.spritesheet("sun","img/sun.png",200,200);
        game.load.image("clouds", "img/clouds.png")
        game.load.audio("bgmusic","sound/bg1.mp3")
        game.load.image("gotomenu", "img/gotomenu.png");
        game.load.image("playbutton","img/play.png");
        game.load.image("pausebutton","img/pause.png");
        game.load.image("restartbutton","img/restart.png");
    },

    create:function(){

        game.physics.startSystem(Phaser.Physics.ARCADE);

        desert = game.add.tileSprite(0,0,800,600, "bg");

        clouds = game.add.tileSprite(0,0,800,600, "clouds");
        
        player = game.add.sprite(50, 100, "player");
        
        platform = game.add.sprite(0, 400, "plat")
        game.physics.arcade.enable(platform);
        platform.body.immovable = true;
        platform.scale.x= 1.5;

        game.physics.enable(player, Phaser.Physics.ARCADE);

        player.animations.add('run',[0,1,2,3],10,true);
        player.animations.add('jump',[5,6,7],5,true);
        game.physics.arcade.enable(player);
        player.body.collideWorldBounds = true;

        cursors = game.input.keyboard.createCursorKeys();
        
        bullets = game.add.group();
        bullets.enableBody = true;
        bullets.physicsBodyType = Phaser.Physics.ARCADE;
        bullets.createMultiple(30, "bullet");
        bullets.setAll("anchor.x", 1);
        bullets.setAll("anchor.y", 0.3);
        bullets.setAll("outOfBoundsKill", true);
        bullets.setAll("checkWorldBounds", true);
        
        fireButton = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
        
        enemy= game.add.group();
        enemy.enableBody = true;
        
        createEnemies(3100);

        enemy2= game.add.group();
        enemy2.enableBody = true;

        createEnemies2(4200);
        
        player.body.collideWorldBounds = true;
        player.body.gravity.y = 1500;
        player.body.bounce.y = 0.2;

        coin= game.add.group();
        coin.enableBody = true;
        
        createCoins(2300);
        
        coin2= game.add.group();
        coin2.enableBody = true;
        
        createCoins2(4600);
        
        score = game.add.text(600,30,'Score: 0',{fill:"black"});
        bestScoreText = game.add.text(600,70,'Best: '+getScore(),{fill:"gold"});
        gameOverText = game.add.text((800/2)-100,600/2,'',{fill:"white"});
        
        
        button = game.add.button(620,420,"button", playerjump);
        button.scale.x = .6;
        button.scale.y= .6;
        
        button2 = game.add.button(23,420,"button2", playershoot);
        button2.scale.x = .6;
        button2.scale.y= .6;  

        sun= game.add.sprite (20,5, "sun")
        sun.scale.x=.8;
        sun.scale.y=.8;
        sun.animations.add('shine',[0,1],1,true);
        sun.animations.play("shine");

        gotomenu = game.add.button(380, 550,"gotomenu", goToMenu);
        gotomenu.scale.x=.5;
        gotomenu.scale.y=.5;

        playbutton = game.add.button(350,500,"playbutton",play);
        playbutton.scale.x = .4;
        playbutton.scale.y= .4;

        pausebutton = game.add.button(460,500,"pausebutton",pause);
        pausebutton.scale.x = .4;
        pausebutton.scale.y= .4;

        restart = game.add.button(400, 500,"restartbutton",restart);
        restart.scale.x= .4;
        restart.scale.y= .4;
    },


    update: function () {
        
        desert.tilePosition.x -=3;
        clouds.tilePosition.x -=2;
        
        game.physics.arcade.collide(player,platform);
        //game.physics.arcade.collide(bullet, enemy);
        game.physics.arcade.overlap(player,platform);
        game.physics.arcade.overlap(player,coin, coins, collectCoins);
        game.physics.arcade.overlap(player,coin2,coins2, collectCoins2);
        game.physics.arcade.overlap(player, enemy, enemies, avoidEnemy);
        game.physics.arcade.overlap(player, enemy2, enemies2, avoidEnemy2);
        game.physics.arcade.overlap(bullet, enemy, killEnemy);
                
        if (cursors.up.isDown)
        {
        player.animations.play("jump");
           player.body.velocity.y = -300;
           player.body.velocity.x = 0;
        }
        else
        {
        player.animations.play("run");
        player.body.velocity.x =0;

        }
        
        if (fireButton.isDown)
            {
                fireBullet();
            }

    },

}


function fireBullet()
{
    if (game.time.now > bulletTime)
        {
           bullet = bullets.getFirstExists(false);
            
            if (bullet)
                {
                    bullet.reset(player.x + 90, player.y + 85);
                    bullet.body.velocity.x = 500;
                    bulletTime = game.time.now + 200;
                    
                }
        }
}

function createEnemies(time)
{
    setInterval(function()
        {
        var enemies = enemy.create(800 + 100, Math.random()+350, 'enemy');
        enemies.body.gravity.x = -30;
        } , time)
}

function createEnemies2(time)
{
    setInterval(function()
        {
        var enemies2 = enemy2.create(800 + 100, Math.random()+370, 'enemy2');
        enemies2.body.gravity.x = -30;
        } , time)
}

function createCoins(time)
{
    setInterval(function()
        {
        var coins = coin.create(800 + 100, Math.random()+280, 'coin');
        coins.body.gravity.x = -30;
        } , time)
}

function createCoins2(time)
{
    setInterval(function()
        {
        var coins2 = coin2.create(800 + 100, Math.random()+250, 'coin2');
        coins2.body.gravity.x = -30;
        } , time)
}

var a=0;

function killEnemy (bullet,enemy)
{
        enemy.kill();
        a= a + 10;
        if(getScore()<=a)
            {
                saveScore(a);
                bestScoreText.text = "Best: "+a; 
             }
                score.text = "Score: "+a;

        bullet.kill();
                
        explode = game.add.sprite((enemy.position.x),(enemy.position.y),"explode");
        explode.animations.add('explosions',[0,1,2,3,4],10,false);
        explode.animations.play("explosions");

        setTimeout(function()
        {
        explode.animations.stop();
        explode.scale.x = 0;
        explode.scale.y = 0;
        explode.kill();
        },2000)
}

var a = 0;

function collectCoins(player,coins){
    a = a + 5;
    coins.kill();
    if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    }
    score.text = "Score: "+a;
}


function collectCoins2(player,coins2){
    a = a + 5;
    coins2.kill();
    if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    }
    score.text = "Score: "+a;
}

function avoidEnemy (player,enemies)
{
    player.kill();
    gameOverText.text = "GAME OVER ";
    game._paused = true;
}

function avoidEnemy2 (player,enemies2)
{
    player.kill();
    gameOverText.text = "GAME OVER ";
    game._paused = true;
}

function saveScore(score){
    localStorage.setItem("gameScore", score);
}

function getScore(){
    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
}

function playerjump(){
button.frame =1;
if(player.body.touching.down){
player.animations.play("jump");
player.body.velocity.y = -500;
    }
setTimeout(function(){
button.frame=0;
},600)
}

function playershoot(){
button2.frame =1;
if(player.body.touching.down){
   fireBullet() }
setTimeout(function(){
button2.frame=0;
},600)
}

function audio(time){
    setInterval(function(){
        bgAudio.play();
        },time)
}

function goToMenu ()
    {
    window.location.href="menu.html";
    {menus.frame=0}  
    setTimeout(function(){
    
    menus.frame=0;
    game._paused=false;
    },50);
    }

    function pause()
{
                 player.visible= false;
                 enemy.visible= false;
                 enemy2.visible= false;
                 coin.visible= false;
                 coin2.visible= false;

}

function play()
{
                player.visible= true;
                 enemy.visible= true;
                 enemy2.visible= true;
                 coin.visible= true;
                 coin2.visible= true;
                
}

function restart()
{
     window.location.href="main.html";
  {restart.frame=0}  
    setTimeout(function(){
    
restart.frame=0;
game._paused=false;
},50);
}
    game.state.add("mainState",mainState);
    game.state.start("mainState");