var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'gameDiv');

var basicGame=function(){}

basicGame.prototype={

    preload:function()
    {
    game.load.image("bg","img/about2.jpg")
    game.load.image("back","img/back.png")  
    },

    create:function(){
    game.physics.startSystem(Phaser.Physics.ARCADE);
    game.add.sprite(0,0,"bg");
    back = game.add.button(10, 480,"back", showMenu);
    // game.load.audio("bgmusic")
    // bgmusic.play();
    },


    update: function ()
    {
    },
}

function showMenu ()
    {
    window.location.href="menu.html";
    {menus.frame=0}  
    setTimeout(function(){
    
    menus.frame=0;
    game._paused=false;
    },50);
    }

    game.state.add("mainGame",basicGame,true);
    game.state.start("mainState");